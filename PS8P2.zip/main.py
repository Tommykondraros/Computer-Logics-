
Input(Yes or No)

Yes("Length ,Width ,Height")

Compute(SquareFootage)

(2 * Length * Width) + 2(2 * Length * Height) + 2(2 * Width * Height)
