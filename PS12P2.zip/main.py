Insert("Sentence")

Insert("Hi my name is")

Reverse("Hi my name is")

Input(Reverse)

Enrer = reverse