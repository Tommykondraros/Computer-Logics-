
Input = LastName

Input = sales

Compute = commission

IfOver100000 = 10%

IfUnder100000 = 5%

Display = name

Display = commission 

display = target

