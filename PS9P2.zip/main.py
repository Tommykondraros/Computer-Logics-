Input = LastName
Input = ExamScores

Compute = avg

Compute = total

Display = lastname

display = total

display = avg