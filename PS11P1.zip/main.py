
Enter = 3
3 = 3 integers
Display = 3 

Insert(99) 
Display main
replace(99) with value(100)

500, 600, 700, 800, 900 
Display
remove(800)
remove(third)

Create(list)
Create("A, B, C, A, A, C")

Display count of grades
display("Index")

display("F is not on list")

Delete second list

Clear second list

Create("Rizzo, Davis, Baez, Happ, Bryan")
Sort(List)

Display(List)

copyright
Reversed(List)
