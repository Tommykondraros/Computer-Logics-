Input(Quantity)
Input(Price)
Input(DiscountRate)
Compute = Discount Amount
Compute = Discouhnted Price

Display = ComputedAmount
