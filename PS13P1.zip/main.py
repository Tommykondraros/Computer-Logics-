
emp_1 = employee
emp_2 = employee

print(emp_1)
print(emp_2)

print(emp_1.email)
print(emp_2.email)

