
input = quantity
input = price

compute = total + tax

Display = total
display = tax