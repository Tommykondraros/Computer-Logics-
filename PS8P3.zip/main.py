
Input(Yes or No)

Yes(Make ,Model ,Code)

Compute(DoorPrice)

Determine(PercentOffMSRP)

(MSRP + 7%*SalesTax)
