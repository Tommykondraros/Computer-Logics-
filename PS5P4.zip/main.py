# Do you want to do this program
Enter(Yes or No)

Enter Last Name

Enter Hours Worked

Enter Rate of Pay

Compute(Gross Pay)

Sum Gross Pay and number of employees

Display Last Name and Gross Pay
