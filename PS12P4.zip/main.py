
Enter("Sentence")

Enter("Lines")
Enter("NumberofLines")
Enter("LeftorRight")

Shift("LeftorRight")
