 # Enter last name, job code and hours worked

Determine pay rate

L=25
return
J=50

A=30

Display last name and gross pay
WindowsError
