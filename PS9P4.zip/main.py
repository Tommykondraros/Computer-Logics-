
Input = LastName
Input = gamescores
input = handicap

compute = avg
compute = avg + handicap

Display = lastname
display = avg
display = avg + handicap
