
Enter(LastName)
Enter(Score)

Display(lowest)
Display(Highest)

f = open(lastname + score)

