
Input(Yes or No)

Yes(LastName ,Month ,Sales)

Compute(MonthsForecast)

ForecastPercentage

Sales * (1 + ForecastPercentage)

