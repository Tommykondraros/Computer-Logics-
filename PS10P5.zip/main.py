Enter = LastName
Enter = battingaverage

Display(BattingAverage)

F = open(Lastname = battingaverage)

Enter = WrongLastName

Display = NameNotFound
