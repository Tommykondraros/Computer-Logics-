# DO you want to do this program

Enter Yes or No

Enter Last Name and Two Exam Scores

Compute Average Exam Score

Display Last Name 

Display Average Score

Display number of students who entered data
