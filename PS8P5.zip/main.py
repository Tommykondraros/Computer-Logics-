
Input(Yes or No)

Yes(Count ,MarketValue)

Compute(Value)

MarketValue * AssessedValuePercentage

("Sum and display all market values")
