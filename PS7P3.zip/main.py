# Enter the destination city, miles travelled and gallons used

Compute miles per gallon

compute cost

display city, miles and cost of gas
