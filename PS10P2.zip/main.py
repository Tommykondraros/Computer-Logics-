
Enter = LastName

Display(LastName)

f = open(lastnames)

Display = examscore

