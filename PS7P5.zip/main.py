# Enter Last Name, credit hours and district code. 

Compute tuition

I=250

O=550

Display name 
Display tuition owned 