
Input(Yes or No)

Yes(LastName ,Miles)

Compute(TicketPrice)

Miles + TicketPrice

Sum(AllTickts)

