# Enter quantity and price

Compute Total

Provide 10% discount for over 10,000

DIsplay price, quantity and total