Enter = LastName
Display10

Display = LastName

Display in reverse

f = open(lastnames)
