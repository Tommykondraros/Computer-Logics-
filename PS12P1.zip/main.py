
Enter("FirstName")
Enter("LastName")
SyntaxWarning
spring("LastName, FirstName")
