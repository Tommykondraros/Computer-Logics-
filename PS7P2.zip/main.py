# Enter Last Name, hits, and at bats

Compute batting average

Display last name and batting average
