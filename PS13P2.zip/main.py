
emp_1(student)
emp_2(class)

print(emp_1)
print(emp_2)

Input = FirstName
Input = LastName
Input = districtcode
