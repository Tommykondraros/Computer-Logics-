# Do you want to do this program

Enter Quantity

Enter Price of Item

Compute extended price

If Extended is > 10000 than discount is 25%

If Not its 10% 

Display Extended Price

Display Discount Amount

Display Total Price

Sum the Discount Price

Display Sm of all Discounts
